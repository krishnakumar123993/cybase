import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'medfield_model.dart';

class medfield extends StatefulWidget {
  const medfield({Key key}) : super(key: key);

  @override
  _medfieldState createState() => _medfieldState();
}

class _medfieldState extends State<medfield> {

     Future <ModelApi> getlist()async{
       var url = "http://143.110.240.107:8000/user/get_medfeed_home";

       var res = await http.get(Uri.parse(url), headers: {
         "Authorization":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYxMjVlZjVmZTVmNWMzOTYxNDI4NDIzYyIsImlhdCI6MTYzMzcwNzA3OCwiZXhwIjoxNjM2Mjk5MDc4fQ.dvxArYOcy_JMdJtz-ypGhrP-zUAmUm8ml5pcs7ijpoY"

       });

      print(res.body);
       return ModelApi.fromJson(jsonDecode(res.body));
     }


  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar:  AppBar(
        backgroundColor: Colors.green,
        title: Text("Medfield"),

      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              color: Colors.red,
              height: 300,
              width: MediaQuery.of(context).size.width,

            ),
           FutureBuilder(
               future: getlist(),
               builder: (context,snapshot){
             return  GridView.builder(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
               crossAxisCount: 3,

             ),
                 itemCount: 3,

                 itemBuilder: (context,index){
               return Container(
                 height: 50,
                 width: 50,
                 child: Text(snapshot.data[index]),
                 color: Colors.red,
               );
             });

           })



          ],
        ),
      ),

    );
  }
}
